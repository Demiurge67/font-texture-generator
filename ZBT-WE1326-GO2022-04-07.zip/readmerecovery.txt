Use the Recovery GUI at 192.168.1.1

Use the Recovery GUI at 192.168.0.1	

	D-Link DIR-860L-B1